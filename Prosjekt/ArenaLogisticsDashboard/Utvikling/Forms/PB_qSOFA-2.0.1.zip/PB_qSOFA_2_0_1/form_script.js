var RESP = "qsofa/qsofa-skår/uspesifisert_hendelse/høy_respirasjonsfrekvens";
var BT = "qsofa/qsofa-skår/uspesifisert_hendelse/lavt_blodtrykk";
var GCS = "qsofa/qsofa-skår/uspesifisert_hendelse/endret_mental_status";
var qSofa = "qsofa/qsofa-skår/uspesifisert_hendelse/qsofa-skår";
var FIELDS_TO_WATCH = [RESP, BT, GCS];
FIELDS_TO_WATCH.forEach(function (field) {
    api.addListener(field, "OnChanged", function (id, value, parent) {
        updateQSofaScore();
    });
});
function updateQSofaScore() {
    //console.log("Updating qSofa score");
    var respVal = api.getFieldValue(RESP);
    var btVal = api.getFieldValue(BT);
    var gcsVal = api.getFieldValue(GCS);
    var ordinals = [respVal, btVal, gcsVal];
    if (isAllSet(ordinals)) {
        //  console.log("All ordinals is set");
        var score = respVal.Value + btVal.Value + gcsVal.Value;
        //console.log("Score is" + score);
        var result = new DvCount();
        result.Magnitude = score;
        api.setFieldValue(qSofa, result);
        ;
    }
    else {
        console.log("Not all ordinals are set - clearing qSOFA score");
        api.clearField(qSofa);
    }
}
function isAllSet(ordinals) {
    for (var index = 0; index < ordinals.length; index++) {
        var o = ordinals[index];
        if (!o || !o.Symbol || !o.Symbol.Value || o.Symbol.Value == null) {
            return false;
        }
    }
    return true;
}
