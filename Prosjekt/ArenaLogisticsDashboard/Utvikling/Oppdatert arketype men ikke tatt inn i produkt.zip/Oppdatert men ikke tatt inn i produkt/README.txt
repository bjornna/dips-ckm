Endringene i denne mappa ble gjort 23.05.19 etter en diskusjon rundt at de dav�rende templater og skjemaer var bygd p� v0 av arketypen openEHR-EHR-ADMIN_ENTRY.logistic_services_dips.
V1 ble opprettet og templater og skjemaer i denne pakken er ferdig satt opp til denne arketypen. Grunnet tidspress i Team Swoosh ble imidlertid dette ikke tatt inn i f�rste iterasjon av produktet.

Oppdateringene skal v�re ferdig og klare til bruk, og trenger kun en liten justering i VAQM'ens aql-binding for � fungere (endre sp�rringen til arketypens v1 istedenfor v0).

--Lars Martin Jensvoll, 23.05.19--