var ANE_1 = "anestesivurdering/hovedprosedyre@Hovedprosedyre/rekvirering/prosedyrenavn";
var ANE_2 = "anestesivurdering/andre_anestesitype@Andre anestesitype/rekvirering/prosedyrenavn";
var ANE_3 = "anestesivurdering/tredje_anestesitype@Tredje anestesitype/rekvirering/prosedyrenavn";
var ANE_4 = "anestesivurdering/fjerde_anestesitype@Fjerde anestesitype/rekvirering/prosedyrenavn";
var ANE_5 = "anestesivurdering/femte_anestesitype@Femte anestesitype/rekvirering/prosedyrenavn";
var SNOMED_ANESTESI_PROSEDYRE = DvCodedText.Parse("SNOMED-CT::399248000|Anestesi prosedyre");
var SNOMED_SEKUNDAR_PROSEDYRE = DvCodedText.Parse("SNOMED-CT::262134003|Sekund�rprosedyre");
var ane1_fields = {
    procedureType: "",
    procedureDetailsType: "",
    procedureDetails: "anestesivurdering/hovedprosedyre@Hovedprosedyre/rekvirering/prosedyredetaljer",
    procedureDetailsName: "anestesivurdering/hovedprosedyre@Hovedprosedyre/rekvirering/prosedyredetaljer/prosedyrenavn"
};
api.addListener(ANE_1, "OnFormInitialized", function (id, value, parent) {
    console.log("ANE1 initialized");
    onInitHideAndClearProcedureDetails(ane1_fields);
});
api.addListener(ANE_1, "OnChanged", function (id, value, parent) {
    console.log("Handle anestesitype main. Require NCMP = " + requireDetailedProcedureCodes(value));
    if (requireDetailedProcedureCodes(value)) {
        if (!hasCluster(ane1_fields.procedureDetails)) {
            api.addField(ane1_fields.procedureDetails);
        }
        api.setOccurrences(ane1_fields.procedureDetails, "1..1", parent);
        api.setOccurrences(ane1_fields.procedureDetailsName, "1..1", parent);
        api.showField(ane1_fields.procedureDetails);
        api.showField(ane1_fields.procedureDetailsName);
    }
    else {
        api.hideField(ane1_fields.procedureDetails);
        api.clearField(ane1_fields.procedureDetails);
        api.setOccurrences(ane1_fields.procedureDetails, "0..0");
        api.setOccurrences(ane1_fields.procedureDetailsName, "0..1");
    }
});
function removeAll(formId) {
    var f = api.getFields(formId);
    f.forEach(function (n) {
        console.log("remove" + n.FormId);
        api.clearField(n.FormId);
        api.hideField(n.FormId);
        api.removeField(n);
    });
}
function hasCluster(formId) {
    var f = api.getFields(formId);
    if (f) {
        return true;
    }
    else {
        return false;
    }
}
var ANE2_FIELDS = {
    procedureType: "anestesivurdering/andre_anestesitype@Andre anestesitype/rekvirering/prosedyretype",
    procedureDetailsType: "anestesivurdering/andre_anestesitype@Andre anestesitype/rekvirering/prosedyredetaljer/prosedyretype",
    procedureDetails: "anestesivurdering/andre_anestesitype@Andre anestesitype/rekvirering/prosedyredetaljer",
    procedureDetailsName: "anestesivurdering/andre_anestesitype@Andre anestesitype/rekvirering/prosedyredetaljer/prosedyrenavn"
};
api.addListener(ANE_2, "OnFormInitialized", function (id) {
    onInitHideAndClearProcedureDetails(ANE2_FIELDS);
});
api.addListener(ANE_2, "OnChanged", function (id, value, parent) {
    handleAnestesiTypeChanged(value, ANE2_FIELDS);
});
var ANE3_FIELDS = {
    procedureType: "anestesivurdering/tredje_anestesitype@Tredje anestesitype/rekvirering/prosedyretype",
    procedureDetailsType: "anestesivurdering/tredje_anestesitype@Tredje anestesitype/rekvirering/prosedyredetaljer/prosedyretype",
    procedureDetails: "anestesivurdering/tredje_anestesitype@Tredje anestesitype/rekvirering/prosedyredetaljer",
    procedureDetailsName: "anestesivurdering/tredje_anestesitype@Tredje anestesitype/rekvirering/prosedyredetaljer/prosedyrenavn"
};
api.addListener("anestesivurdering/tredje_anestesitype@Tredje anestesitype", "OnChildAdded", function (id, value, parent) {
    console.log("Child added" + id);
    onInitHideAndClearProcedureDetails(ANE3_FIELDS);
});
api.addListener(ANE_3, "OnFormInitialized", function (id) {
    console.log("ANE3 initialisert");
    onInitHideAndClearProcedureDetails(ANE3_FIELDS);
});
api.addListener(ANE_3, "OnChanged", function (id, value, parent) {
    handleAnestesiTypeChanged(value, ANE3_FIELDS);
});
var ANE4_FIELDS = {
    procedureType: "anestesivurdering/fjerde_anestesitype@Fjerde anestesitype/rekvirering/prosedyretype",
    procedureDetailsType: "anestesivurdering/fjerde_anestesitype@Fjerde anestesitype/rekvirering/prosedyredetaljer/prosedyretype",
    procedureDetails: "anestesivurdering/fjerde_anestesitype@Fjerde anestesitype/rekvirering/prosedyredetaljer",
    procedureDetailsName: "anestesivurdering/fjerde_anestesitype@Fjerde anestesitype/rekvirering/prosedyredetaljer/prosedyrenavn",
};
api.addListener(ANE_4, "OnFormInitialized", function (id) {
    onInitHideAndClearProcedureDetails(ANE4_FIELDS);
});
api.addListener("anestesivurdering/fjerde_anestesitype@Fjerde anestesitype", "OnChildAdded", function (id) {
    onInitHideAndClearProcedureDetails(ANE4_FIELDS);
});
api.addListener(ANE_4, "OnChanged", function (id, value, parent) {
    handleAnestesiTypeChanged(value, ANE4_FIELDS);
});
var ANE5_FIELDS = {
    procedureType: "anestesivurdering/femte_anestesitype@Femte anestesitype/rekvirering/prosedyretype",
    procedureDetailsType: "anestesivurdering/femte_anestesitype@Femte anestesitype/rekvirering/prosedyredetaljer/prosedyretype",
    procedureDetails: "anestesivurdering/femte_anestesitype@Femte anestesitype/rekvirering/prosedyredetaljer",
    procedureDetailsName: "anestesivurdering/femte_anestesitype@Femte anestesitype/rekvirering/prosedyredetaljer/prosedyrenavn"
};
api.addListener(ANE_5, "OnFormInitialized", function (id) {
    onInitHideAndClearProcedureDetails(ANE5_FIELDS);
});
api.addListener("anestesivurdering/femte_anestesitype@Femte anestesitype", "OnChildAdded", function (id) {
    onInitHideAndClearProcedureDetails(ANE5_FIELDS);
});
api.addListener(ANE_5, "OnChanged", function (id, value, parent) {
    handleAnestesiTypeChanged(value, ANE5_FIELDS);
});
function onInitHideAndClearProcedureDetails(fields) {
    console.log("onInitHideAndClearProcedureDetails " + fields.procedureDetails);
    api.hideField(fields.procedureDetails);
    api.clearField(fields.procedureDetails);
    api.setOccurrences(fields.procedureDetails, "0..1");
    api.setOccurrences(fields.procedureDetailsName, "0..1");
}
function handleAnestesiTypeChanged(value, fields) {
    if (isEmpty(value)) {
        clearFields([fields.procedureType, fields.procedureDetailsType]);
    }
    else {
        api.setFieldValue(fields.procedureType, SNOMED_ANESTESI_PROSEDYRE);
        api.setFieldValue(fields.procedureDetailsType, SNOMED_SEKUNDAR_PROSEDYRE);
    }
    if (requireDetailedProcedureCodes(value)) {
        api.showField(fields.procedureDetails);
        api.setOccurrences(fields.procedureDetails, "1..1");
        api.setOccurrences(fields.procedureDetailsName, "1..1");
    }
    else {
        api.hideField(fields.procedureDetails);
        api.clearField(fields.procedureDetails);
        api.setOccurrences(fields.procedureDetails, "0..1");
        api.setOccurrences(fields.procedureDetailsName, "0..1");
    }
}
function clearFields(fields) {
    fields.forEach(function (formId) {
        api.clearField(formId);
    });
}
function isEmpty(value) {
    if (value === null) {
        return true;
    }
    var val = value;
    if (val.Value == null && val.DefiningCode.CodeString == null) {
        return true;
    }
    return false;
}
/**
 * Return true if DvCodedText one of the following values
 * ARK-ANE-HOVEDTYPE::P::P Plexus
 * ARK-ANE-HOVEDTYPE::L::L Annen ledning
 *
 * @param value
 */
function requireDetailedProcedureCodes(value) {
    var code = value;
    //console.log(code);
    var codeString = code.DefiningCode.CodeString;
    switch (codeString) {
        case "Code002": // DEBUG
            return true;
        case "Code003": // DEBUG
            return true;
        case "L": ////ARK-ANE-HOVEDTYPE::L::L Annen ledning
            return true;
        case "P": //ARK-ANE-HOVEDTYPE::P::P Plexus
            return true;
        default:
            return false;
    }
}
